<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Type;
use App\Models\ProjectType;
use App\Models\Banner;
use App\Models\Bed;
use App\Models\Project;
use App\Models\Invoice;
use App\Models\Agents;
use App\Models\Property;
use App\Models\Community;
use App\Models\Landingpageseos;
use App\Models\Location;
use App\Models\Leads;
use Illuminate\Support\Facades\DB;
use App;
use Illuminate\Support\Facades\Redirect;
use Validator;
use App\Models\Dld;
use Illuminate\Support\Facades\URL;




class FronthomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function HomePage()
    {
        return $this->index("");
    }


    public function autocomplete(Request $request)
    {
        $results = [];

        if($request->has('q')){
            $search = $request->q;

            $results = Property::select('title_en AS title')
            ->where(function($q) use ($search) {
                $q->where('title_en', 'LIKE', '%' . $search . '%');
			})
			->get();

            $address = Property::select('address_en AS title')
            ->where(function($q) use ($search) {
                $q->where('address_en', 'LIKE', '%' . $search . '%');
			})
			->get();

            $results->merge($address);
        }

        return response()->json($results);
    }




    public function fetch(Request $request)
    {
     if($request->get('query'))
     {
        $query = $request->get('query');
        $data = DB::table('opt_locations')
            ->where('name_en', 'LIKE', "%{$query}%")
            ->get();
        $output = '<ul class="dropdown-menu" style="display:block; position:relative;  list-style-type: none;padding: 0; border: 1px solid #ddd;border-radius: 0px;">';
        foreach($data as $row)
        {
        $output .= '
        <li class="li-2" style="padding: 3px; font-size: 16px;"><a href="#">'.$row->name_en.'</a></li>
        ';
        }
        $output .= '</ul>';
        echo $output;
     }
    }


    public function fetch_dld(Request $request)
    {


     if($request->get('query'))
     {
        $query = $request->get('query');




        $data = DB::table('opt_dld_transactions')
                 ->select('area_name_en', DB::raw('count(*) as total'))
                 ->where('area_name_en', 'LIKE', "%{$query}%")

                 ->groupBy('area_name_en')


                 ->take(10)
                 ->get();

                 $building = DB::table('opt_dld_transactions')
                 ->select('building_name_en', DB::raw('count(*) as total' ))
                 ->where('building_name_en', 'LIKE', "%{$query}%")
                 ->groupBy('building_name_en')


                 ->take(10)
                 ->get();





        $output = '<ul class="dropdown-menu" style="display:block; position:absolute;  list-style-type: none;padding: 0; border: 1px solid #ddd;border-radius: 0px;">';
        foreach($building as $row)
        {
        $output .= '
        <li class="li-2" style="padding: 3px; font-size: 16px;"><a href="#">'.$row->building_name_en.'</a></li>
        ';
        }
        $output .= '</ul>';
        echo $output;


        $output = '<ul class="dropdown-menu" style="display:block; position:absolute;  list-style-type: none;padding: 0; border: 1px solid #ddd;border-radius: 0px;">';
        foreach($data as $row)
        {
        $output .= '
        <li class="li-2" style="padding: 3px; font-size: 16px;"><a href="#">'.$row->area_name_en.'</a></li>
        ';
        }
        $output .= '</ul>';
        echo $output;
     }
    }


    public function fetch_arabic(Request $request)
    {
     if($request->get('query'))
     {
        $query = $request->get('query');
        $data = DB::table('opt_locations')
            ->where('name_ar', 'LIKE', "%{$query}%")
            ->get();
        $output = '<ul class="dropdown-menu" style="display:block; position:relative;  list-style-type: none;padding: 0; border: 1px solid #ddd;border-radius: 0px;">';
        foreach($data as $row)
        {
        $output .= '
        <li class="li-2" style="padding: 3px; font-size: 16px;text-align:right;"><a href="#">'.$row->name_ar.'</a></li>
        ';
        }
        $output .= '</ul>';
        echo $output;
     }
    }





    public function index($lang = "")
    {

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;


        $project = Project::with(['images','developers','project_types'])->orderBy('id', 'desc')->take(6)->get();

        $off_plan_projects = Project::with(['images','developers','project_types'])->where('project_status', '1')->orderBy('id', 'desc')->take(4)->get();

        $projectmobile = Project::with(['images','developers','project_types'])->orderBy('id', 'desc')->take(3)->get();

        $properties_for_sale = Property::with(['images', 'locationss','cityss'])->where('cat_id','1')->where('type_id','1')->inRandomOrder()->take(6)->get();

        $properties_for_rent = Property::with(['images', 'locationss','cityss'])->where('cat_id','1')->where('type_id','2')->inRandomOrder()->take(6)->get();

        $communities = Community::with(['images'])->limit(4)->get();

        $banner = Banner::where('status', '1')->get();

        $agents = Agents::where('status', 1)->get();

        $landingpageseo = Landingpageseos::where('id','1')->first();

        //return $properties_for_sale;

        $this->data['communities'] = $communities;


        $this->data['off_plan_projects'] = $off_plan_projects;

        $this->data['agents'] = $agents;

        $this->data['banner'] = $banner;

        $this->data['project'] = $project;

        $this->data['landingpageseo'] = $landingpageseo;

        $this->data['projectsmobile'] = $projectmobile;

        $this->data['properties_for_sale'] = $properties_for_sale;

        $this->data['properties_for_rent'] = $properties_for_rent;

        // dd($agents[0]);

        return view('index',$this->data);

    }




    public function searchbyproject( Request $request )
    {

        $search = $request->search;

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;


        $project = Project::where('title_en', 'Like' , '%' . $search . '%' )->where('status','1')->orderBy('id', 'desc')->get();

        //return $project;

        $this->data['project'] = $project;

        return view('search',$this->data);

    }




    public function thankyou($lang = '' )
    {



        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;




        return view('thankyou',$this->data);

    }

    public function sell($lang = '' )
    {



        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();

        $landingpageseo = Landingpageseos::where('id','7')->first();

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;



        $this->data['landingpageseo'] = $landingpageseo;




        return view('sell',$this->data);

    }



    public function sitemap($lang = '')
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();


        $Dubaiareas = Community::where([['status', 1]])->orderby('title_en')->get();


        $Dubaiprojects = Project::where([['status', 1]])->where([['pro_status', 1]])->orderby('title_en')->get();

        $Dubaireadyprojects = Project::where([['status', 1]])->where([['pro_status', 2]])->orderby('title_en')->get();

        $Dubailuxuryprojects = Project::where([['status', 1]])->where([['pro_status', 3]])->orderby('title_en')->get();

        $dubaiproperties_sale = Property::where([['status', 1]])->where([['type_id', 1]])->orderby('title_en')->get();

        $dubaiproperties_rent = Property::where([['status', 1]])->where([['type_id', 2]])->orderby('title_en')->get();




        $this->data['dubaicommunity'] = $Dubaiareas;

        $this->data['dubaiprojects'] = $Dubaiprojects;

        $this->data['dubaireadyprojects'] = $Dubaireadyprojects;

        $this->data['dubailuxuryprojects'] = $Dubailuxuryprojects;

        $this->data['properties_sale'] = $dubaiproperties_sale;

        $this->data['properties_rent'] = $dubaiproperties_rent;



        return view('sitemap',$this->data);

    }


    public function services($lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;



        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();


        $landingpageseo = Landingpageseos::where('id','4')->first();



        $this->data['landingpageseo'] = $landingpageseo;



        return view('services',$this->data);

    }





    public function mortgage($lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;



        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();




        return view('mortgage',$this->data);

    }





     public function sale_transaction($lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;



        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();


        $dld = Dld::orderBy('id', 'desc')->paginate(30);

        //return $dld;

        $this->data['dld'] = $dld;

        return view('sale_transaction',$this->data);

    }





    public function sale_transaction_search(Request $request, $lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;



        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();


        // $dld = Dld::where( 'property_type_en', 'LIKE', '%' . $request->area_name_en . '%' )
        // ->where('area_name_en', 'LIKE', '%' . $request->search . '%')
        // ->where('procedure_name_en', 'LIKE', '%' . $request->transtion_type . '%')
        // ->where('reg_type_en', 'LIKE', '%' . $request->status . '%')
        // ->where('instance_date', '>=', $date_from)
        // ->where('instance_date', '<=', $date_to)
        // ->orderBy('instance_date', 'desc')
        // ->paginate($request->records);

        $dld = Dld::where('area_name_en', 'LIKE', "%{$request->search}%");




        if($request->property_type != null){
            $dld->where('property_type_en' , $request->property_type);
        }
        if($request->transtion_type != null){
            $dld->where('procedure_name_en', $request->transtion_type);
        }
        if($request->status != null){
            $dld->where('reg_type_en', $request->status);
        }
        if($request->date_from != null){
            $dld->where('instance_date', '>=', $request->date_from);
        }
        if($request->date_to != null){
            $dld->where('instance_date', '<=', $request->date_to);
        }


        $dld = $dld->orderBy('id', 'desc')->paginate($request->records);

              if($dld->isEmpty())
        {
            $dld = Dld::where('building_name_en', 'LIKE', "%{$request->search}%");

            if($request->property_type != null){
                $dld->where('property_type_en' , $request->property_type);
            }
            if($request->transtion_type != null){
                $dld->where('procedure_name_en', $request->transtion_type);
            }
            if($request->status != null){
                $dld->where('reg_type_en', $request->status);
            }
            if($request->date_from != null){
                $dld->where('instance_date', '>=', $request->date_from);
            }
            if($request->date_to != null){
                $dld->where('instance_date', '<=', $request->date_to);
            }


            $dld = $dld->orderBy('id', 'desc')->paginate($request->records);
        }



        $this->data['request'] = $request;


        $this->data['dld'] = $dld;

        return view('sale_transaction',$this->data);

    }





    public function aboutus($lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();

        $project = Project::with(['images','developers','project_types'])->orderBy('id', 'desc')->take(6)->get();


        //return $project;

        $this->data['projects'] = $project;

        return view('aboutus',$this->data);

    }






    public function faqs($lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();





        return view('faqs',$this->data);

    }





    public function onlinepayments($lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();





        return view('onlinepayments',$this->data);

    }





    public function book_a_viewing($lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();





        return view('book_viewing',$this->data);

    }





    public function privacyandpolicy($lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();





        return view('privacypolicy',$this->data);

    }




    public function termsandconditions($lang = '' )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();





        return view('terms',$this->data);

    }




    public function valuation(  )
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;



        return view('valuation', $this->data);
    }


    public function career($lang = "")
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();

        $landingpageseo = Landingpageseos::where('id','5')->first();

        $this->data['landingpageseo'] = $landingpageseo;

        return view('career',$this->data);

    }





    public function contactus($lang = "")
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();

        $landingpageseo = Landingpageseos::where('id','5')->first();

        $this->data['landingpageseo'] = $landingpageseo;

        return view('contactus',$this->data);

    }


    public function check_invoice($lang = "")
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;


        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();

        $landingpageseo = Landingpageseos::where('id','5')->first();

        $this->data['landingpageseo'] = $landingpageseo;

        return view('check_invoice',$this->data);

    }


    public function find_invoice(Request $request)
	{

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;


		$name = $request->name;
		$invoice_no = $request->invoice_no;
		$contract_no = $request->contract_no;

		$invoice = Invoice::where('invoice_no', $invoice_no)->where('contract_no',$contract_no)->first();



        if ( $invoice )
        {


			$invoice_details = Invoice::where('invoice_no', $invoice_no)->first();


			return view('invoice',compact("invoice_details"));

        }

        else
        {

            return Redirect::to('/invoice')->with('message','Your Invoice is Not Available !');

        }

	}





    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }



    public function request_detail_project(Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;


        $project_id=$request->project;

		$Project = Project::find($project_id);



		$Leads = new Leads();



		$Leads->full_name = $request->name;
		$Leads->lead_name = $Project->title_en;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();

        \Mail::send('email/project_email',
        array(
            'project_name' => $Project->title_en,
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),
        ), function($message) use ($request)
          {

             $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });

          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });

          return redirect('/en/thankyou');



    }


    public function request_detail_project_detail(Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;


        $project_id=$request->project;

		$Project = Project::find($project_id);



		$Leads = new Leads();



		$Leads->full_name = $request->name;
		$Leads->lead_name = $Project->title_en;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();

        \Mail::send('email/project_email',
        array(
            'project_name' => $Project->title_en,
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),
        ), function($message) use ($request)
          {

             $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });

          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });

          return redirect('/en/thankyou');



    }

    public function request_detail_property(Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        $property_id = $request->property;

		$property = Property::find($property_id);




		$Leads = new Leads();



		$Leads->full_name = $request->name;
		$Leads->lead_name = $property->title_en;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();


        \Mail::send('email/property_email',
        array(
            'property_name' => $property->title_en,
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),
        ), function($message) use ($request)
          {

             $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });

          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });

          return redirect('/en/thankyou');



    }

    public function request_detail_community(Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;


        $Leads = new Leads();


		$Leads->page_url = $request->url_path;
		$Leads->full_name = $request->name;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();

        $community_id=$request->project;

		$community = community::find($community_id);



        \Mail::send('email/community_email',
        array(
            'community_name' => $community->title_en,
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),
        ), function($message) use ($request)
          {

             $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });


          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });

          return redirect('/en/thankyou');



    }

    public function contactus_email( Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        $Leads = new Leads();


		$Leads->page_url = $request->url_path;
		$Leads->full_name = $request->name;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();

        \Mail::send('email/contactus_email',
        array(
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),
            'user_message' => $request->get('message'),
        ), function($message) use ($request)
          {

            $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });

          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });

          return redirect('/en/thankyou');
    }

    public function mortgage_email( Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        $Leads = new Leads();


		$Leads->page_url = $request->url_path;
		$Leads->full_name = $request->name;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();


        \Mail::send('email/mortgage_email',
        array(
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),
            'user_message' => $request->get('message'),
        ), function($message) use ($request)
          {

            $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });


          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });

          return redirect('/en/thankyou');
    }




    public function request_detail( Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        $Leads = new Leads();


		$Leads->page_url = $request->url_path;
		$Leads->full_name = $request->name;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();

        \Mail::send('email/request_email',
        array(
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),

        ), function($message) use ($request)
          {

            $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });


          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });

          return redirect('/en/thankyou');
    }


    public function book_view_email( Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        $Leads = new Leads();


		$Leads->page_url = $request->url_path;
		$Leads->full_name = $request->name;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();

        $property_detail = Property::with(['images', 'locationss', 'property_type','agentss'])->where('id',$request->property_id)->first();



        \Mail::send('email/book_view_email',
        array(
            'property_name' => $property_detail->title_en,
            'date' => $request->get('book_date'),
            'time' => $request->get('book_time'),
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),

        ), function($message) use ($request)
          {

            $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });

          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });

          return redirect('/en/thankyou');
    }


    public function book_viewing_email( Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        $Leads = new Leads();


		$Leads->page_url = $request->url_path;
		$Leads->full_name = $request->name;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();


        \Mail::send('email/book_viewing_email',
        array(

            'date' => $request->get('book_date'),
            'time' => $request->get('book_time'),
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),

        ), function($message) use ($request)
          {

            $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });


          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });

          return redirect('/en/thankyou');
    }


    public function career_email(Request $request)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        // $Leads = new Leads();


        // $Leads->page_url = $request->url_path;
        // $Leads->full_name = $request->name;
        // $Leads->phone = $request->phone;
        // $Leads->email = $request->email;
        // $Leads->page_url = url()->previous();
        // $Leads->ip_address = $_SERVER["REMOTE_ADDR"];
        // $Leads->type_id = 1;
        // $Leads->save();


        $validator = Validator::make($request->all(), [
            "file_name" => "required|mimes:pdf|max:5000",
        ]);



        \Mail::send('email/career_email',
        array(
            'category' => $request->get('category'),
            'name' => $request->get('name'),
			'language' => $request->get('language'),
			'nationality' => $request->get('nationality'),
			'email' => $request->get('email'),
			'phone' => $request->get('phone'),

        ), function($message) use ($request)
          {

			 $message->to('hr@edgerealty.ae')->subject('Edge Realty');
			 $message->attach($request->file_name->getRealPath(), array(
				'as' => $request->file_name->getClientOriginalName(), // If you want you can chnage original name to custom name
				'mime' => $request->file_name->getMimeType())
			);



        });

        \Mail::send('email/user_email',
        array(

        ), function($message) use ($request)
          {

             $message->to($request->email)->subject('Edge Realty Registration');
          });



		return redirect('/en/thankyou');


	}




    public function book_valuation_email(Request $request)

    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        $Leads = new Leads();


		$Leads->page_url = $request->url_path;
		$Leads->full_name = $request->name;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();


        \Mail::send('email/book_valuation_email',
        array(

            'address' => $request->get('address'),
            'type' => $request->get('type'),
            'property_type' => $request->get('property_type'),
            'bedrooms' => $request->get('bedrooms'),
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),

        ), function($message) use ($request)
          {

            $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });


        \Mail::send('email/user_email',
        array(

        ), function($message) use ($request)
        {

            $message->to($request->email)->subject('Edge Realty Registration');
        });


		return redirect('/en/thankyou');


	}


    public function project_documentSubmit(Request $request)

    {
        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;


		$Leads = new Leads();


		$Leads->page_url = $request->url_path;
		$Leads->full_name = $request->name;
		$Leads->phone = $request->phone;
		$Leads->email = $request->email;
		$Leads->page_url = url()->previous();
		$Leads->ip_address = $_SERVER["REMOTE_ADDR"];
		$Leads->type_id = 1;
		$Leads->save();


		$project_id=$request->project;

		$Project = Project::find($project_id);



        \Mail::send('email/project_document_email',
        array(


            'Project_name' => $Project->title_en,
            'name' => $request->get('name'),
            'email' => $request->get('email'),
            'phone_number' => $request->get('phone'),

        ), function($message) use ($request)
          {

            $message->to('lead@edgerealty.ae')->subject('Edge Realty');
          });


          \Mail::send('email/user_email',
          array(

          ), function($message) use ($request)
            {

               $message->to($request->email)->subject('Edge Realty Registration');
            });


		$file=  "https://edgerealty.ae/"."uploads/projects/documents/".$request->document_id."/".$request->document_name;

		$headers = array(
				'Content-Type: application/pdf',
				);

		//Response::download($file, "$request->document_name", $headers);

		return redirect($file);

	}



    public function team($lang = '' ) {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;
        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }

		// General Webmaster Settings

		$conLag = App::getLocale();

        $agents = Agents::orderBy('id', 'asc')->where('status', 1)->paginate(16);


        $this->data['blogs'] = $agents;

        // dd($agents);

        return view('team',$this->data);
    }





    public function team_detail($lang = '', $id)
    {

        $footerLuxuryProjects = Project::with(['images','developers','project_types'])->where('project_status', '3')->orderBy('id', 'desc')->take(8)->get();

        $footerCommunities = Community::with(['images'])->orderBy('id', 'desc')->take(8)->get();

        $this->data['footerLuxuryProjects'] = $footerLuxuryProjects;

        $this->data['footerCommunities'] = $footerCommunities;

        $slug_link = $id;
        //
        if ($lang != "") {
            // Set Language
            App::setLocale($lang);
            \Session::put('locale', $lang);
        }


		$conLag = App::getLocale();


        $projects = Project::with(['images','developers','project_types'])->where('agent_id',$slug_link)->get();

        $properties = Property::with(['images', 'locationss','cityss'])->where('agent_id',$slug_link)->get();

        $agent = Agents::where('id', $slug_link)->get();

        // dd($properties);

        $this->data['projects'] = $projects;

        $this->data['properties'] = $properties;

        $this->data['agent'] = $agent[0];

        return view('team_detail',$this->data);
    }


}
